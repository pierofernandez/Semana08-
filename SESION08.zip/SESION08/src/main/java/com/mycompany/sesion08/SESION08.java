/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sesion08;

import sesion8.entidades.SmartPhone;
import sesion8.entidades.SmartTV;

/**
 *
 * @author USER
 */
public class SESION08 {

    public static void main(String[] args) {
        
        SmartPhone miSmartPhone = new SmartPhone();
        SmartTV miSmartTV = new SmartTV ();
        
       
    }
}
